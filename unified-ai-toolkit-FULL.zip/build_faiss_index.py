
from langchain.document_loaders import TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
import os
from dotenv import load_dotenv

load_dotenv()
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

loader = TextLoader("sample_10k.txt")
docs = loader.load()

embedding = OpenAIEmbeddings()
db = FAISS.from_documents(docs, embedding)
db.save_local("faiss_index")

print("✅ FAISS index created.")

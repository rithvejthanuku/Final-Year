# Unified AI Toolkit (Final Year Project)

This Streamlit-based toolkit integrates multiple Generative AI utilities including retrieval-based QA, document evaluation, rubric scoring, and prompt classification.

## 🔧 Features
- Fin RAG – Financial claim verification with retrieval
- Chat RAG – Conversational QA over documents
- Ceres Evaluation – Lesson scoring for 20+ non-STEM subjects
- Eclipse Generator – Training content expansion
- Shield – AI response comparison with rubrics
- Yutori – Wellness workflow generator
- Query Complexity – Prompt difficulty scorer
- SQLite logging + ZIP export included

## 🚀 Setup Instructions

### 1. Clone or unzip the repo

```bash
git clone https://github.com/yourusername/unified-ai-toolkit.git
cd unified-ai-toolkit
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Add your OpenAI API key

Create a `.env` file:
```
OPENAI_API_KEY=your_openai_key_here
```

### 4. Build FAISS vector index

```bash
python build_faiss_index.py
```

### 5. Run the Streamlit app

```bash
streamlit run unified_ai_toolkit.py
```

---

## 🧠 Sample Input File

Ensure `sample_10k.txt` is filled with a dummy or real 10-K report to support Fin RAG and Chat RAG modules.
